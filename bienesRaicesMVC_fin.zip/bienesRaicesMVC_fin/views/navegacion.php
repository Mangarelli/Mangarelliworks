
<a href="propiedades/crear" class="boton boton-verde">Nueva Propiedad</a>
<a href="vendedores/crear" class="boton boton-amarillo">Nuevo Vendedor</a>
